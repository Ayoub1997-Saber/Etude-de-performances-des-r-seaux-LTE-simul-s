﻿/******************** Projet de fin d’etudes ********************
* Nom du projet :
* *
− Etude de performances des reseaux LTE *
* * *
Realise par :
* *
− Ayoub Taihi
* *
− Racim Haffaf
* * * *
Encadre par :
* *
− M. Abdennebi
**

**************************************************************/
/* * I− Librairies * */

//Added for flow monitor
#include "ns3/flow-monitor.h"
#include "ns3/flow-monitor-helper.h"
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/mobility-module.h"
#include "ns3/lte-module.h"
#include "ns3/applications-module.h"
#include "ns3/point-to-point-module.h"
#include "ns3/config-store-module.h"
#include "ns3/netanim-module.h"
using namespace ns3;
NS_LOG_COMPONENT_DEFINE ("LenaX2HandoverMeasures");

/**************************************************************
/* * II − Methodes * */

void
 NotifyConnectionEstablishedUe (std::string context,
                                uint64_t numero_identity,
                                uint16_t cellule_identity,
                                uint16_t radio_identity)
 {
   std::cout << context
             << " UE IMSI " << numero_identity
             << ": connecte a cellule_identity " << cellule_identity
             << " avec radio_identity RNTI " << radio_identity
             << std::endl;
 }
 
 void
 NotifyHandoverStartUe (std::string context,
                        uint64_t numero_identity,
                        uint16_t cellule_identity,
                        uint16_t radio_identity,
                        uint16_t target_cellule_identity)
 {
   std::cout << context
             << " UE IMSI " << numero_identity
             << ": connecte provisoirement a cellule_identity " << cellule_identity
             << " avec radio_identity RNTI " << radio_identity
             << " établissement du handover pour cellule_identity " << target_cellule_identity
             << std::endl;
 }
 
 void
 NotifyHandoverEndOkUe (std::string context,
                        uint64_t numero_identity,
                        uint16_t cellule_identity,
                        uint16_t radio_identity)
 {
   std::cout << context
             << " UE IMSI " << numero_identity
             << " : handover effectue pour cellule_identity" << cellule_identity
             << " avec radio_identity RNTI" << radio_identity
             << std::endl;
 }
 
 void
 NotifyConnectionEstablishedEnb (std::string context,
                                 uint64_t numero_identity,
                                 uint16_t cellule_identity,
                                 uint16_t radio_identity)
 {
   std::cout << context
             << " eNB cellule_identity " << cellule_identity
             << " : connection effectue : UE avec IMSI " << numero_identity
             << " RNTI " << radio_identity
             << std::endl;
 }
 
 void
 NotifyHandoverStartEnb (std::string context,
                         uint64_t numero_identity,
                         uint16_t cellule_identity,
                         uint16_t radio_identity,
                         uint16_t target_cellule_identity)
 {
   std::cout << context
             << " eNB cellule_identity " << cellule_identity
             << " : debut du handover : UE avec IMSI " << numero_identity
             << " RNTI " << radio_identity
             << " pour cellule_identity " << target_cellule_identity
             << std::endl;
 }
 
 void
 NotifyHandoverEndOkEnb (std::string context,
                         uint64_t numero_identity,
                         uint16_t cellule_identity,
                         uint16_t radio_identity)
 {
   std::cout << context
             << " eNB cellule_identity " << cellule_identity
             << ": handover complete UE avec IMSI " << numero_identity
             << " RNTI " << radio_identity
             << std::endl;
 }
 

 //*****************************************************************************
// * III − Programme principal * * /


int main (int argc, char *argv[])
{
  CommandLine cmd;

  Ptr<LteHelper> lte = CreateObject<LteHelper> ();

  // Instanciation de certains objets communs ( par exemple , l’objet Channel ) .
  // Methodes de configuration et d’ajout des ENodesB et des UEs .

  Config::SetDefault ("ns3::UdpClient::Interval", TimeValue (MilliSeconds (1000)));
  Config::SetDefault ("ns3::UdpClient::MaxPackets", UintegerValue (100000));
  Config::SetDefault ("ns3::LteHelper::UseIdealRrc", BooleanValue (false));

  // Mise en oeuvre du handover .

  Ptr<PointToPointEpcHelper> epcHelper = CreateObject<PointToPointEpcHelper> ();
   lte->SetEpcHelper (epcHelper);
   lte->SetSchedulerType ("ns3::RrFfMacScheduler");
 
   lte->SetHandoverAlgorithmType ("ns3::A2A4RsrqHandoverAlgorithm");
   lte->SetHandoverAlgorithmAttribute ("ServingCellThreshold",
                                             UintegerValue (30));
   lte->SetHandoverAlgorithmAttribute ("NeighbourCellOffset",
                                             UintegerValue (1));

  // Creation du Packet Data Network Gateway (packet_gateway) .

  Ptr<Node> packet_gateway = epcHelper->GetPgwNode ();
 
  // Configuration , installation et creation d’une machine distante .
  NodeContainer noeud_machine;
  noeud_machine.Create (1);
  Ptr<Node> machine_distance = noeud_machine.Get (0);
  InternetStackHelper internet;
  internet.Install (noeud_machine);

  // Creation d’un reseau Internet .
  PointToPointHelper liaison;
  liaison.SetDeviceAttribute ("DataRate", DataRateValue (DataRate ("100Gb/s")));
  liaison.SetDeviceAttribute ("Mtu", UintegerValue (1500));
  liaison.SetChannelAttribute ("Delay", TimeValue (Seconds (0.010)));
  NetDeviceContainer machines_internet = liaison.Install (packet_gateway, machine_distance);
  Ipv4AddressHelper ipv4;
  ipv4.SetBase ("1.0.0.0", "255.0.0.0");
  Ipv4InterfaceContainer internetIpIfaces = ipv4.Assign (machines_internet);
  Ipv4Address remoteHostAddr = internetIpIfaces.GetAddress (1);


  // Routage Internet ( vers le reseau LTE ) .
  Ipv4StaticRoutingHelper route_ipv4;
  Ptr<Ipv4StaticRouting> route_machine_ipv4 = route_ipv4.GetStaticRouting (machine_distance->GetObject<Ipv4> ());

  // Creation des interfaces :
  // − 0 signifie local host .
  // − 1 signifie le peripherique p2p .
  route_machine_ipv4->AddNetworkRouteTo (Ipv4Address ("7.0.0.0"), Ipv4Mask ("255.0.0.0"), 1);

  // Creation des objets "Node " pour les ENodes B et les UEs .
  NodeContainer enbNodes;
  enbNodes.Create (2);
  NodeContainer ueNodes;
  ueNodes.Create (6);

  // Installation d’un scenario de mobilite dans les ENodesB ( scenario que nous avons défini ! )
   Ptr<ListPositionAllocator> enb_postion = CreateObject<ListPositionAllocator> ();

   Vector enbPosition (300 , 200, 0);
   enb_postion->Add (enbPosition);

   Vector enbPosition1 (600 , 200, 0);
   enb_postion->Add (enbPosition1);

   MobilityHelper enb_mobilite;
   enb_mobilite.SetMobilityModel ("ns3::ConstantPositionMobilityModel");
   enb_mobilite.SetPositionAllocator (enb_postion);
   enb_mobilite.Install (enbNodes);
 
  // Installation d’un scenario de mobilite dans les UEs ( scenario que nous avons défini ! )
   MobilityHelper ue_mobilite;
   ue_mobilite.SetMobilityModel ("ns3::ConstantVelocityMobilityModel");
   ue_mobilite.Install (ueNodes);
   for (uint16_t i = 0; i < 3; i++)
    {
      ueNodes.Get (i)->GetObject<MobilityModel> ()->SetPosition (Vector (0, 10 * (i), 0));
      ueNodes.Get (i)->GetObject<ConstantVelocityMobilityModel> ()->SetVelocity (Vector (20, 10+i*3, 0));
    }
    for (uint16_t i = 3; i < 6; i++)
    {
      ueNodes.Get (i)->GetObject<MobilityModel> ()->SetPosition (Vector (800, 10 * (i), 0));
      ueNodes.Get (i)->GetObject<ConstantVelocityMobilityModel> ()->SetVelocity (Vector (-20, 10 + (i-3)*3, 0));
    }

  // Installation d’une pile de protocoles LTE  sur les ENodes B .
  NetDeviceContainer enbDevs;
  enbDevs = lte->InstallEnbDevice (enbNodes);

  // Installation d’une pile de protocoles LTE  sur les UEs .
  NetDeviceContainer ueDevs;
  ueDevs = lte->InstallUeDevice (ueNodes);

  // Installation d’une pile IP sur les UEs .
   internet.Install (ueNodes);
   Ipv4InterfaceContainer ueIpIfaces;
   ueIpIfaces = epcHelper->AssignUeIpv4Address (NetDeviceContainer (ueDevs));

   // Liaison de chaque triplet d’UEs [U+FFFD] leur ENode B , pour les raisons suivantes :
   // − Configuration de chaque UE en fonction de la configuration ENode B .
   // − Creation d’une connexion RRC entre eux .
   for (uint16_t i = 0; i < 3; i++)
     {
       lte->Attach (ueDevs.Get (i), enbDevs.Get (0));
     }
    for (uint16_t i = 3; i < 6; i++)
     {
       lte->Attach (ueDevs.Get (i), enbDevs.Get (1));
     }


  NS_LOG_LOGIC ("parametre applications");
  uint16_t dlPort = 10000;
  uint16_t ulPort = 20000;
  Ptr<UniformRandomVariable> debut_temps = CreateObject<UniformRandomVariable> ();
   debut_temps->SetAttribute ("Min", DoubleValue (0));
   debut_temps->SetAttribute ("Max", DoubleValue (0.010));

 // Activation du canal radio "bearer" de flux de donnees entre chaque UE et son ENodeB auquel il est rattaché 
  for (uint32_t u = 0; u < 6; ++u)
     {
       Ptr<Node> ue = ueNodes.Get (u);

       // Definition de la passerelle ( gateway ) par defaut pour chaque UE
       Ptr<Ipv4StaticRouting> route_ue_ipv4 = route_ipv4.GetStaticRouting (ue->GetObject<Ipv4> ());
       route_ue_ipv4->SetDefaultRoute (epcHelper->GetUeDefaultGatewayAddress (), 1);
 
       for (uint32_t b = 0; b < 1; ++b)
         {
           ++dlPort;
           ++ulPort;
 
           ApplicationContainer client_Apps;
           ApplicationContainer server_Apps;
 
           NS_LOG_LOGIC ("installation UDP DL pour UE " << u);
           UdpClientHelper dlClientHelper (ueIpIfaces.GetAddress (u), dlPort);
           client_Apps.Add (dlClientHelper.Install (machine_distance));
           PacketSinkHelper dlPacketSinkHelper ("ns3::UdpSocketFactory",
                                                InetSocketAddress (Ipv4Address::GetAny (), dlPort));
           server_Apps.Add (dlPacketSinkHelper.Install (ue));
 
           NS_LOG_LOGIC ("installation UDP UL pour UE " << u);
           UdpClientHelper ulClientHelper (remoteHostAddr, ulPort);
           client_Apps.Add (ulClientHelper.Install (ue));
           PacketSinkHelper ulPacketSinkHelper ("ns3::UdpSocketFactory",
                                                InetSocketAddress (Ipv4Address::GetAny (), ulPort));
           server_Apps.Add (ulPacketSinkHelper.Install (machine_distance));
 
           Ptr<EpcTft> tft = Create<EpcTft> ();
           EpcTft::PacketFilter dlpf;
           dlpf.localPortStart = dlPort;
           dlpf.localPortEnd = dlPort;
           tft->Add (dlpf);
           EpcTft::PacketFilter ulpf;
           ulpf.remotePortStart = ulPort;
           ulpf.remotePortEnd = ulPort;
           tft->Add (ulpf);
           EpsBearer bearer (EpsBearer::NGBR_VIDEO_TCP_DEFAULT);
           lte->ActivateDedicatedEpsBearer (ueDevs.Get (u), bearer, tft);
 
           Time startTime = Seconds (debut_temps->GetValue ());
           server_Apps.Start (startTime);
           client_Apps.Start (startTime);
 
         } 
     }

     // Ajout des interfaces X2 pour l’activation du handover .
    lte->AddX2Interface (enbNodes);

    // Connexion des usagers personnalises pour l’etablissement de la connexion RRC et la notification du handover
   Config::Connect ("/NodeList/*/DeviceList/*/LteEnbRrc/ConnectionEstablished",
                    MakeCallback (&NotifyConnectionEstablishedEnb));
   Config::Connect ("/NodeList/*/DeviceList/*/LteUeRrc/ConnectionEstablished",
                    MakeCallback (&NotifyConnectionEstablishedUe));
   Config::Connect ("/NodeList/*/DeviceList/*/LteEnbRrc/HandoverStart",
                    MakeCallback (&NotifyHandoverStartEnb));
   Config::Connect ("/NodeList/*/DeviceList/*/LteUeRrc/HandoverStart",
                    MakeCallback (&NotifyHandoverStartUe));
   Config::Connect ("/NodeList/*/DeviceList/*/LteEnbRrc/HandoverEndOk",
                    MakeCallback (&NotifyHandoverEndOkEnb));
   Config::Connect ("/NodeList/*/DeviceList/*/LteUeRrc/HandoverEndOk",
                    MakeCallback (&NotifyHandoverEndOkUe));

  // Flow monitor
  Ptr<FlowMonitor> flow_Monitor;
  FlowMonitorHelper flow_Helper;
  flow_Monitor = flow_Helper.InstallAll();

  // Precision du temps d’arret de la simulation .
  Simulator::Stop (Seconds (45));

  /* Ceci est necessaire pour l’arret de la simulation , car :
   − L’evenement de debut de sous−trame est planifie a plusieurs reprises ,
   − Le planificateur du simulateur NS3 ne manquera donc jamais d’evenements
  */
    lte->EnablePhyTraces ();
    lte->EnableMacTraces ();
    lte->EnableRlcTraces ();

  // Execution de la simulation .
    AnimationInterface anim ("simulation.xml");
    anim.SetMobilityPollInterval(Seconds(1));
    anim.SetMaxPktsPerTraceFile (1000000000);
  // anim.EnablePacketMetadata(true);

  Simulator::Run ();
  flow_Monitor->SerializeToXmlFile("lte_log.xml", true, true);
  Simulator::Destroy ();
  return 0;
}