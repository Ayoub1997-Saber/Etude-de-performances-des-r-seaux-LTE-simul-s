clc;
clear all;
close all;


%%  Performances de notre réseau LTE simulé par NS3. %%
%%%%%%%%%%%%%%%%%%%%%%
       % 1. Débit en fonction du SNR. %
       
data_throughput = importdata('SNRVSThroughput_.plt');                      % Lecture du fichier contenant les informations des débits et leurs SNRs correspondant. 
SNR = data_throughput([1:end],1);                                          % Extraction des SNRs (données de la colonne #1).
throughput = data_throughput([1:end],2);                                   % Extraction des débits (données de la colonne #2).


figure;
plot(SNR, throughput, 'LineWidth', 2, 'Color', [0.9414,0.014,0.1614]);     % Représentation graphique du débit.  
xlim([10 20.79])
title("Courbe de débit de transmission en fonction du temps")
xlabel("SNR(dB)")
ylabel("Db(Mbps)")
grid on;

%%%%%%%%%%%%%%%%%%%%%%
       % 2. Délai d'attente %

data_delay = importdata('DlPdcpStats.txt');                                % Lecture du fichier contenant les informations des délais d'attente.
time = data_delay([1:end],2);                                              % Extraction des temps d'envoi des paquets (données de la colonne #2).
delay = data_delay([1:end],12);                                            % Extraction des délais d'attente (données de la colonne #12). 

figure;

plot(time, delay, 'LineWidth', 4, 'Color', [0.614,0.564,0.874]);           % Représentation graphique du délai d'attente.

title("Courbe de délai d'attente en fonction du temps de transmission")
xlabel("Δt(s)");       ylabel("t(s)")
grid on;

%%%%%%%%%%%%%%%%%%%%%%
       % 3. Perte de paquets et taux de perte %
             % 3.1 Calcul de perte de paquets et sa représentation graphique %

data_packet_loss = importdata('DlRlcStats.txt');                           % Lecture du fichier contenant les informations correspondant aux paquets.
nTx = data_packet_loss([1:end], 8);                                        % Extraction du nombre de paquets émis (données de la colonne #8).
nRx = data_packet_loss([1:end], 10);                                       % Extraction du nombre de paquets reçus (données de la colonne #10).
time = data_packet_loss([1:end], 2);                                       % Extraction de l'information du temps (données de la colonne #2).

figure;
plot(time, abs(nRx - nTx), 'LineWidth', 4, 'Color', [0.414, 0.6344, 0.174]);     % Représentation graphique de perte de paquets.
ylim([-10 1000])
title("Courbe de perte de paquets en fonction du temps de transmission")
xlabel("t(s)");       ylabel("Paquets perdus")
grid on;

             % 3.2 Taux de perte de paquets %

rate_loss = abs(nRx - nTx)./nTx;                                           % Calcul du taux (pourcentage) de perte de paquets (différence entre le nombre de paquets émis et reçus sur le nombre de paquets émis).
